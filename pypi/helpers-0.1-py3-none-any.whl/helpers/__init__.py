import js, asyncio
DB_NAME = "JupyterLite Storage"
async def get_contents(path, db_name=DB_NAME):
    """use the IndexedDB API to acess JupyterLite's in-browser (for now) storage
    for documentation purposes, the full names of the JS API objects are used.
    see https://developer.mozilla.org/en-US/docs/Web/API/IDBRequest
    """
    # we only ever expect one result, either an error _or_ success
    queue = asyncio.Queue(1)

    IDBOpenDBRequest = js.self.indexedDB.open(db_name)
    IDBOpenDBRequest.onsuccess = IDBOpenDBRequest.onerror = queue.put_nowait

    await queue.get()

    if IDBOpenDBRequest.result is None:
        return None

    IDBTransaction = IDBOpenDBRequest.result.transaction("files", "readonly")
    IDBObjectStore = IDBTransaction.objectStore("files")
    IDBRequest = IDBObjectStore.get(path, "key")
    IDBRequest.onsuccess = IDBRequest.onerror = queue.put_nowait

    await queue.get()

    return IDBRequest.result.to_py() if IDBRequest.result else None
