import js, asyncio
DB_NAME = "JupyterLite Storage"
async def get_contents(path, db_name=DB_NAME):
    """use the IndexedDB API to acess JupyterLite's in-browser (for now) storage
    for documentation purposes, the full names of the JS API objects are used.
    see https://developer.mozilla.org/en-US/docs/Web/API/IDBRequest
    """
    # we only ever expect one result, either an error _or_ success
    queue = asyncio.Queue(1)

    IDBOpenDBRequest = js.self.indexedDB.open(db_name)
    IDBOpenDBRequest.onsuccess = IDBOpenDBRequest.onerror = queue.put_nowait

    await queue.get()

    if IDBOpenDBRequest.result is None:
        return None

    IDBTransaction = IDBOpenDBRequest.result.transaction("files", "readonly")
    IDBObjectStore = IDBTransaction.objectStore("files")
    IDBRequest = IDBObjectStore.get(path, "key")
    IDBRequest.onsuccess = IDBRequest.onerror = queue.put_nowait

    await queue.get()

    return IDBRequest.result.to_py() if IDBRequest.result else None


async def make_uploader():
    import piplite
    await piplite.install("ipywidgets")
    import ipywidgets as widgets

    uploader  = widgets.FileUpload(multiple=True)
    display(uploader)
    loaded = widgets.Output()
    with loaded:
        print("loaded: ", end='')
    display(loaded)

    def on_upload_change(change):
        owner = change['owner']
        metadata = owner.metadata
        for fm in metadata:
            filename = fm['name']
            open(filename, 'wb').write(owner.value[filename]['content'])
            with loaded:
                print(f'"{filename}"', end=', ')

    uploader.observe(on_upload_change, names='_counter')
    return uploader
